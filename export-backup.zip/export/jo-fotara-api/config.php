<?php
// config.php - Secure configuration file for JoFotara integration

// JoFotara configuration
$config = [
    // Client credentials 
    'jofotara' => [
        'client_id' => '769fdf05-2e0c-4032-b5c0-c221b6460dc1',
        'client_secret' => 'Gj5nS9wyYHRadaVffz5VKB4v4wlVWyPhcJvrTD4NHtMICbD/QjqjMznWe/ySGVQksaauYh4rG3znqQMEiQDnK8DDJMU0AAbxhGxef/vKcjFzeMoRSPZqfdAd4633O8hVDOuZIjh2MtxgKYz2/5LGkTaH75uKCykhS+YLW2EWE/Q+PFVHRyREKD3coQTsnlxebvHUIgnRjVHMUa9n7kXwe6fa4PNIdsljv0EMNmY7PSqngtKOnBRXbUiCFOgtj+Bb5ckfyo7/TiTAIAii5KuFjA=='
    ],
    
    // Your company information - REPLACE THESE WITH YOUR ACTUAL INFO
    'company' => [
        'name' => 'Softylus',
        'tin' => '10662162',
        'income_source_sequence' => '16053990'
    ],
    
    // Debugging and logging
    'debug' => true,
    'log_path' => __DIR__ . '/jofotara-integration.log'
];

return $config;