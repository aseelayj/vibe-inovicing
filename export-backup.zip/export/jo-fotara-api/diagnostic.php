<?php
/**
 * Diagnostic script for JoFotara integration
 * Helps identify common configuration and setup issues
 */

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>JoFotara Integration Diagnostic</h1>";

// Check PHP version
echo "<h2>PHP Environment</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
$minPhpVersion = "8.0.0";
if (version_compare(PHP_VERSION, $minPhpVersion, '<')) {
    echo "<p style='color:red;'>WARNING: PHP version is below 8.0.0, which is required for JoFotara SDK</p>";
}

// Check required extensions
$required_extensions = ['curl', 'json', 'mbstring', 'xml', 'openssl'];
echo "<h3>Required Extensions</h3>";
echo "<ul>";
foreach ($required_extensions as $ext) {
    $loaded = extension_loaded($ext);
    echo "<li style='color:" . ($loaded ? "green" : "red") . ";'>";
    echo "$ext: " . ($loaded ? "Loaded" : "NOT LOADED");
    echo "</li>";
}
echo "</ul>";

// Check PHP settings
echo "<h3>PHP Settings</h3>";
echo "<ul>";
echo "<li>Memory Limit: " . ini_get('memory_limit') . "</li>";
echo "<li>Max Execution Time: " . ini_get('max_execution_time') . " seconds</li>";
echo "<li>File Uploads: " . (ini_get('file_uploads') ? "Enabled" : "Disabled") . "</li>";
echo "<li>Display Errors: " . (ini_get('display_errors') ? "Enabled" : "Disabled") . "</li>";
echo "</ul>";

// Check file system
echo "<h2>File System</h2>";
echo "<ul>";

// Check if directories exist
$dir = __DIR__;
echo "<li>Current Directory: $dir</li>";

// Check vendor directory
$vendorDir = $dir . '/vendor';
$vendorExists = is_dir($vendorDir);
echo "<li style='color:" . ($vendorExists ? "green" : "red") . ";'>";
echo "Vendor Directory: " . ($vendorExists ? "Exists" : "MISSING");
echo "</li>";

// Check composer autoload
$autoloadFile = $vendorDir . '/autoload.php';
$autoloadExists = file_exists($autoloadFile);
echo "<li style='color:" . ($autoloadExists ? "green" : "red") . ";'>";
echo "Composer Autoload: " . ($autoloadExists ? "Exists" : "MISSING");
echo "</li>";

// Check JoFotara SDK
$sdkDir = $vendorDir . '/jafar-albadarneh/jofotara';
$sdkExists = is_dir($sdkDir);
echo "<li style='color:" . ($sdkExists ? "green" : "red") . ";'>";
echo "JoFotara SDK: " . ($sdkExists ? "Installed" : "NOT INSTALLED");
echo "</li>";

// Check config file
$configFile = $dir . '/config.php';
$configExists = file_exists($configFile);
echo "<li style='color:" . ($configExists ? "green" : "red") . ";'>";
echo "Config File: " . ($configExists ? "Exists" : "MISSING");
echo "</li>";

// Check log file
$logFile = $dir . '/jofotara-integration.log';
$logFileExists = file_exists($logFile);
$logDirWritable = is_writable(dirname($logFile));
echo "<li>Log File: " . ($logFileExists ? "Exists" : "Does not exist yet") . "</li>";
echo "<li style='color:" . ($logDirWritable ? "green" : "red") . ";'>";
echo "Log Directory Writable: " . ($logDirWritable ? "Yes" : "NO");
echo "</li>";

echo "</ul>";

// Try loading config (if exists)
if ($configExists) {
    echo "<h2>Configuration Check</h2>";
    
    try {
        $config = require $configFile;
        echo "<p style='color:green;'>Configuration file loaded successfully</p>";
        
        // Check for required config sections
        $checks = [
            'jofotara' => isset($config['jofotara']),
            'jofotara.client_id' => isset($config['jofotara']['client_id']),
            'jofotara.client_secret' => isset($config['jofotara']['client_secret']),
            'company' => isset($config['company']),
            'company.name' => isset($config['company']['name']),
            'company.tin' => isset($config['company']['tin']),
            'company.income_source_sequence' => isset($config['company']['income_source_sequence']),
        ];
        
        echo "<h3>Configuration Sections</h3>";
        echo "<ul>";
        foreach ($checks as $key => $exists) {
            echo "<li style='color:" . ($exists ? "green" : "red") . ";'>";
            echo "$key: " . ($exists ? "Present" : "MISSING");
            echo "</li>";
        }
        echo "</ul>";
        
        // Check for placeholder values
        if (isset($config['company'])) {
            $placeholders = [
                'company.name' => $config['company']['name'] === 'YOUR_COMPANY_NAME',
                'company.tin' => $config['company']['tin'] === 'YOUR_COMPANY_TIN',
                'company.income_source_sequence' => $config['company']['income_source_sequence'] === 'YOUR_INCOME_SOURCE_SEQUENCE',
            ];
            
            $hasPlaceholders = false;
            foreach ($placeholders as $placeholder) {
                if ($placeholder) {
                    $hasPlaceholders = true;
                    break;
                }
            }
            
            if ($hasPlaceholders) {
                echo "<p style='color:red;'>WARNING: Configuration contains placeholder values that need to be replaced</p>";
                echo "<ul>";
                foreach ($placeholders as $key => $isPlaceholder) {
                    if ($isPlaceholder) {
                        echo "<li style='color:red;'>$key is still set to a placeholder value</li>";
                    }
                }
                echo "</ul>";
            } else {
                echo "<p style='color:green;'>All placeholder values have been replaced</p>";
            }
        }
        
    } catch (Exception $e) {
        echo "<p style='color:red;'>Error loading configuration: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}

// Test JoFotara SDK loading (if vendor exists)
if ($vendorExists && $autoloadExists) {
    echo "<h2>JoFotara SDK Test</h2>";
    
    try {
        require_once $autoloadFile;
        
        // Check if the main class exists
        if (class_exists('JBadarneh\JoFotara\JoFotaraService')) {
            echo "<p style='color:green;'>JoFotara SDK loaded successfully</p>";
            
            // Try to instantiate the service if config exists and is valid
            if ($configExists && isset($config['jofotara']) && isset($config['jofotara']['client_id']) && isset($config['jofotara']['client_secret'])) {
                try {
                    $service = new JBadarneh\JoFotara\JoFotaraService(
                        $config['jofotara']['client_id'], 
                        $config['jofotara']['client_secret']
                    );
                    echo "<p style='color:green;'>JoFotara service instantiated successfully</p>";
                } catch (Exception $e) {
                    echo "<p style='color:red;'>Error creating JoFotara service: " . htmlspecialchars($e->getMessage()) . "</p>";
                }
            }
        } else {
            echo "<p style='color:red;'>JoFotara SDK class not found. The package may not be installed correctly.</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color:red;'>Error loading JoFotara SDK: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}

echo "<h2>Summary</h2>";
echo "<p>This diagnostic tool helps identify common configuration issues with your JoFotara integration.</p>";
echo "<p>If you're seeing RED items above, those need to be fixed before the integration will work properly.</p>";
echo "<p>Timestamp: " . date('Y-m-d H:i:s') . "</p>";