<?php
/**
 * Test script for JoFotara middleware
 * Run this locally to test your endpoint
 */

// Replace with your actual domain
$url = 'https://staging.softylus.com/jo-fotara-api/jofotara-middleware.php';

// Sample test data that mimics what Zoho Flow would send
$testData = [
    'invoice_id' => 'TEST001',
    'invoice_number' => 'INV-TEST-001',
    'invoice_date' => '2025-04-03',
    'customer_name' => 'Test Customer',
    'customer_tin' => '123456789',
    'payment_terms' => 'Due on Receipt',
    'line_items' => [
        [
            'quantity' => 1,
            'rate' => 100,
            'name' => 'Test Product',
            'tax_percentage' => 16
        ]
    ]
];

// Initialize cURL session
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($testData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

// Disable SSL verification for testing only
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

// Execute cURL request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// Display results
echo "HTTP Code: " . $httpCode . "\n\n";

if ($error) {
    echo "Error: " . $error . "\n";
} else {
    echo "Response: \n";
    // Format JSON for readability if it's valid JSON
    if ($response && isJson($response)) {
        $responseData = json_decode($response, true);
        echo json_encode($responseData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo $response;
    }
}

function isJson($string) {
    json_decode($string);
    return json_last_error() === JSON_ERROR_NONE;
}