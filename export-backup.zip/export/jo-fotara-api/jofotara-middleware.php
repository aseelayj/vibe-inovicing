<?php
/**
 * JoFotara Middleware API for Zoho Books Integration
 * 
 * This file serves as an API endpoint that Zoho Flow can call
 * to process invoices through the JoFotara e-invoicing system.
 */

// Enable detailed error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Enable error logging to a file
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php-errors.log');

// Import required classes
use JBadarneh\JoFotara\JoFotaraService;
use JBadarneh\JoFotara\Response\JoFotaraResponse;

// Load dependencies
try {
    if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
        throw new Exception('Vendor autoload.php not found - Composer dependencies may not be installed properly');
    }
    
    require __DIR__ . '/vendor/autoload.php';
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Dependency loading error: ' . $e->getMessage()
    ]);
    exit;
}

// Load configuration safely
try {
    if (!file_exists(__DIR__ . '/config.php')) {
        throw new Exception('Configuration file not found');
    }
    
    $config = require_once __DIR__ . '/config.php';
    
    // Validate configuration
    if (!isset($config['jofotara']) || !isset($config['jofotara']['client_id']) || !isset($config['jofotara']['client_secret'])) {
        throw new Exception('JoFotara configuration missing');
    }
    
    if (!isset($config['company']) || !isset($config['company']['name']) || !isset($config['company']['tin']) || !isset($config['company']['income_source_sequence'])) {
        throw new Exception('Company configuration missing');
    }
    
    // Check for placeholder values
    if ($config['company']['name'] === 'YOUR_COMPANY_NAME' || 
        $config['company']['tin'] === 'YOUR_COMPANY_TIN' || 
        $config['company']['income_source_sequence'] === 'YOUR_INCOME_SOURCE_SEQUENCE') {
        throw new Exception('Company configuration contains placeholder values - please update config.php with your actual information');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Set up logging
function logMessage($level, $message, $data = []) {
    global $config;
    
    $logPath = isset($config['log_path']) ? $config['log_path'] : __DIR__ . '/jofotara-integration.log';
    
    try {
        $timestamp = date('Y-m-d H:i:s');
        $logData = json_encode([
            'timestamp' => $timestamp, 
            'level' => $level, 
            'message' => $message, 
            'data' => $data
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        
        if ($logData === false) {
            $logData = json_encode([
                'timestamp' => $timestamp,
                'level' => 'error',
                'message' => 'Failed to encode log data',
                'error' => json_last_error_msg()
            ]);
        }
        
        file_put_contents($logPath, $logData . PHP_EOL, FILE_APPEND);
    } catch (Exception $e) {
        // If logging fails, write to PHP error log
        error_log('Failed to write to log file: ' . $e->getMessage());
    }
}

// Read JSON input from Zoho Flow
try {
    $input = file_get_contents('php://input');
    if ($input === false) {
        throw new Exception('Failed to read input data');
    }
    
    $data = json_decode($input, true);
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON input: ' . json_last_error_msg());
    }
} catch (Exception $e) {
    logMessage('error', 'Input processing error', ['error' => $e->getMessage()]);
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Input error: ' . $e->getMessage()
    ]);
    exit;
}

// Log incoming request (excluding sensitive data)
logMessage('info', 'Received request from Zoho Flow', [
    'invoice_id' => $data['invoice_id'] ?? 'unknown',
    'timestamp' => date('Y-m-d H:i:s'),
    'is_credit_invoice' => $data['is_credit_invoice'] ?? 'not set',
    'has_original_invoice_id' => isset($data['original_invoice_id']) ? 'yes' : 'no'
]);

// Basic validation
if (!isset($data['invoice_id']) || !isset($data['invoice_number'])) {
    logMessage('error', 'Missing required fields', ['data' => $data]);
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Missing required fields'
    ]);
    exit;
}

try {
    // Log before initializing JoFotara service
    logMessage('debug', 'About to initialize JoFotara service', [
        'client_id_length' => strlen($config['jofotara']['client_id']),
        'client_secret_length' => strlen($config['jofotara']['client_secret']),
        'company_name_set' => !empty($config['company']['name']),
        'company_tin_set' => !empty($config['company']['tin']),
        'income_source_set' => !empty($config['company']['income_source_sequence'])
    ]);
    
    // Initialize JoFotara service
    try {
        $jofotara = new JoFotaraService(
            $config['jofotara']['client_id'],
            $config['jofotara']['client_secret']
        );
        logMessage('debug', 'JoFotara service initialized successfully');
    } catch (Exception $e) {
        logMessage('error', 'Failed to initialize JoFotara service', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Set basic invoice information
    try {
        $basicInfo = $jofotara->basicInformation()
            ->setInvoiceId($data['invoice_number'])
            ->setUuid(generateUuid()) // Helper function to generate UUID v4
            ->setIssueDate(formatDate($data['invoice_date'] ?? date('Y-m-d')))
            ->setInvoiceType('general_sales');
        
        // Add optional invoice note if provided
        if (isset($data['invoice_note']) && !empty($data['invoice_note'])) {
            $basicInfo->setNote($data['invoice_note']);
        }
        
        // Set payment method - determine from Zoho data if possible
        if (isset($data['payment_terms']) && stripos($data['payment_terms'], 'due on receipt') !== false) {
            $basicInfo->cash();
        } else {
            $basicInfo->receivable();
        }
        
        // Handle credit invoice (void invoice)
        if (isset($data['is_credit_invoice']) && $data['is_credit_invoice'] === true) {
            if (!isset($data['original_invoice_id']) || !isset($data['original_invoice_uuid']) || !isset($data['original_full_amount'])) {
                throw new InvalidArgumentException('Credit invoices require original invoice ID, UUID, and full amount');
            }
            
            $basicInfo->asCreditInvoice(
                $data['original_invoice_id'],
                $data['original_invoice_uuid'],
                floatval($data['original_full_amount'])
            );
            
            // Set reason for return (required for credit invoices)
            if (isset($data['reason_for_return']) && !empty($data['reason_for_return'])) {
                $jofotara->setReasonForReturn($data['reason_for_return']);
            } else {
                $jofotara->setReasonForReturn('Invoice void/reversal');
            }
            
            logMessage('debug', 'Credit invoice configured', [
                'original_invoice_id' => $data['original_invoice_id'],
                'original_invoice_uuid' => $data['original_invoice_uuid'],
                'original_full_amount' => $data['original_full_amount'],
                'reason' => $data['reason_for_return'] ?? 'Invoice void/reversal'
            ]);
        }
        
        logMessage('debug', 'Basic information set successfully');
    } catch (Exception $e) {
        logMessage('error', 'Failed to set basic information', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Set seller information (your company)
    try {
        $jofotara->sellerInformation()
            ->setName($config['company']['name'])
            ->setTin($config['company']['tin']);
        
        logMessage('debug', 'Seller information set successfully');
    } catch (Exception $e) {
        logMessage('error', 'Failed to set seller information', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Set customer information
    try {
        $customerTin = getCustomerTin($data);
        $customerInfo = $jofotara->customerInformation()
            ->setId($customerTin, 'TIN')
            ->setName($data['customer_name']);
        
        // Add optional customer fields if provided
        if (isset($data['customer_phone']) && !empty($data['customer_phone'])) {
            $customerInfo->setPhone($data['customer_phone']);
        }
        
        if (isset($data['customer_city_code']) && !empty($data['customer_city_code'])) {
            $customerInfo->setCityCode($data['customer_city_code']);
        }
        
        if (isset($data['customer_postal_code']) && !empty($data['customer_postal_code'])) {
            $customerInfo->setPostalCode($data['customer_postal_code']);
        }
        
        logMessage('debug', 'Customer information set successfully', ['customer_tin' => $customerTin]);
    } catch (Exception $e) {
        logMessage('error', 'Failed to set customer information', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Set supplier income source (required)
    try {
        $jofotara->supplierIncomeSource($config['company']['income_source_sequence']);
        logMessage('debug', 'Supplier income source set successfully');
    } catch (Exception $e) {
        logMessage('error', 'Failed to set supplier income source', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Add line items
    try {
        if (!isset($data['line_items']) || !is_array($data['line_items'])) {
            $data['line_items'] = [
                [
                    'quantity' => 1,
                    'rate' => 100,
                    'name' => 'Default Item',
                    'tax_percentage' => 16
                ]
            ];
            logMessage('warning', 'No line items found, using default item');
        }
        
        foreach ($data['line_items'] as $index => $item) {
            $lineItem = $jofotara->items()->addItem($index + 1);
            
            $quantity = $item['quantity'] ?? 1;
            $rate = $item['rate'] ?? 0;
            $discountPercentage = $item['discount'] ?? 0;
            
            $lineItem->setQuantity($quantity)
                ->setUnitPrice($rate)
                ->setDescription($item['name'] ?? 'Item ' . ($index + 1));
            
            // Handle tax
            if (isset($item['tax_percentage']) && $item['tax_percentage'] > 0) {
                $lineItem->tax($item['tax_percentage']);
            } else {
                $lineItem->zeroTax();
            }
            
            // Handle discount - convert percentage to amount
            if ($discountPercentage > 0 && $discountPercentage < 100) {
                try {
                    $subtotal = round($quantity * $rate, 2);
                    $discountAmount = round($subtotal * ($discountPercentage / 100), 2);
                    
                    // Only apply discount if it's meaningful and doesn't exceed subtotal
                    if ($discountAmount > 0.01 && $discountAmount < $subtotal) {
                        $lineItem->setDiscount($discountAmount);
                        logMessage('debug', 'Discount applied to item', [
                            'item_index' => $index,
                            'discount_percentage' => $discountPercentage,
                            'discount_amount' => $discountAmount,
                            'subtotal' => $subtotal,
                            'tax_exclusive_after_discount' => $subtotal - $discountAmount
                        ]);
                    } else {
                        logMessage('debug', 'Discount skipped (too small or invalid)', [
                            'item_index' => $index,
                            'discount_percentage' => $discountPercentage,
                            'discount_amount' => $discountAmount,
                            'subtotal' => $subtotal
                        ]);
                    }
                } catch (Exception $discountError) {
                    logMessage('warning', 'Failed to set discount for item', [
                        'item_index' => $index,
                        'discount_percentage' => $discountPercentage,
                        'error' => $discountError->getMessage()
                    ]);
                    // Continue without discount if it fails
                }
            }
        }
        
        logMessage('debug', 'Line items added successfully', ['count' => count($data['line_items'])]);
    } catch (Exception $e) {
        logMessage('error', 'Failed to add line items', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Calculate invoice totals
    try {
        $jofotara->invoiceTotals();
        logMessage('debug', 'Invoice totals calculated successfully');
    } catch (Exception $e) {
        logMessage('error', 'Failed to calculate invoice totals', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Send to JoFotara
    try {
        logMessage('debug', 'About to send to JoFotara');
        $response = $jofotara->send();
        
        // Log response type for debugging
        logMessage('debug', 'Response type information', [
            'class' => is_object($response) ? get_class($response) : 'not an object',
            'methods' => is_object($response) ? get_class_methods($response) : [],
            'is_response_object' => $response instanceof JoFotaraResponse
        ]);
        
        // Initialize response data
        $responseData = [];
        
        // Handle the response based on the SDK documentation
        if (method_exists($response, 'isSuccess') && $response->isSuccess()) {
            // Check if there are validation errors even in "successful" responses
            $hasErrors = false;
            $errors = [];
            
            if (method_exists($response, 'hasErrors') && $response->hasErrors()) {
                $hasErrors = true;
                $errors = method_exists($response, 'getErrors') ? $response->getErrors() : [];
            }
            
            if ($hasErrors) {
                logMessage('error', 'JoFotara response has validation errors', [
                    'errors' => $errors
                ]);
                
                // Return error response immediately
                http_response_code(400);
                
                // Create user-friendly error message
                $errorMessages = [];
                foreach ($errors as $error) {
                    if (isset($error['EINV_MESSAGE'])) {
                        $errorMessages[] = $error['EINV_MESSAGE'];
                    }
                }
                
                $userMessage = !empty($errorMessages) ? implode('. ', $errorMessages) : 'Invoice validation failed';
                
                echo json_encode([
                    'success' => false,
                    'message' => $userMessage,
                    'errors' => $errors,
                    'details' => 'Invoice validation failed at JoFotara service'
                ]);
                exit;
            }
            
            // Success response - extract data using available methods
            $responseData = [
                'uuid' => method_exists($response, 'getInvoiceUuid') ? $response->getInvoiceUuid() : '',
                'status' => method_exists($response, 'getInvoiceStatus') ? $response->getInvoiceStatus() : 'success',
                'qrCode' => method_exists($response, 'getQrCode') ? $response->getQrCode() : '',
                'invoiceNumber' => method_exists($response, 'getInvoiceNumber') ? $response->getInvoiceNumber() : '',
                'invoiceXml' => method_exists($response, 'getInvoiceAsXml') ? $response->getInvoiceAsXml() : '',
                'statusCode' => method_exists($response, 'getStatusCode') ? $response->getStatusCode() : 200,
                'rawResponse' => method_exists($response, 'getRawResponse') ? $response->getRawResponse() : null
            ];
            
            logMessage('debug', 'JoFotara response successful', [
                'status' => $responseData['status'],
                'uuid' => $responseData['uuid']
            ]);
        } else {
            // Handle errors
            $errors = [];
            if (method_exists($response, 'getErrors')) {
                $errors = $response->getErrors();
            } elseif (isset($response['errors'])) {
                $errors = $response['errors'];
            }
            
            logMessage('error', 'JoFotara response indicates error', [
                'errors' => $errors
            ]);
            
            // Return error response immediately
            http_response_code(400);
            
            // Create user-friendly error message
            $errorMessages = [];
            foreach ($errors as $error) {
                if (isset($error['EINV_MESSAGE'])) {
                    $errorMessages[] = $error['EINV_MESSAGE'];
                }
            }
            
            $userMessage = !empty($errorMessages) ? implode('. ', $errorMessages) : 'Invoice validation failed';
            
            echo json_encode([
                'success' => false,
                'message' => $userMessage,
                'errors' => $errors,
                'details' => 'Invoice validation failed at JoFotara service'
            ]);
            exit;
        }
        
    } catch (Exception $e) {
        logMessage('error', 'Failed to send to JoFotara', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        throw $e;
    }
    
    // Log successful response
    logMessage('info', 'Invoice processed successfully', [
        'invoice_id' => $data['invoice_id'],
        'response_data_keys' => is_array($responseData) ? array_keys($responseData) : 'no data'
    ]);
    
    // Return success response
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Invoice processed successfully',
        'data' => [
            'jofotara_uuid' => $responseData['uuid'] ?? '',
            'jofotara_status' => $responseData['status'] ?? '',
            'jofotara_qrcode' => $responseData['qrCode'] ?? '',
            'jofotara_invoice_number' => $responseData['invoiceNumber'] ?? '',
            'jofotara_invoice_xml' => $responseData['invoiceXml'] ?? '',
            'processed_date' => date('Y-m-d H:i:s'),
            'raw_response' => $responseData // Include full response for debugging
        ]
    ]);
    
} catch (Exception $e) {
    // Log error
    logMessage('error', 'Error processing invoice', [
        'invoice_id' => $data['invoice_id'] ?? 'unknown',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
    
    // Return error response
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error processing invoice: ' . $e->getMessage()
    ]);
}

// Helper functions
function generateUuid() {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function formatDate($zohoDate) {
    try {
        // Convert from YYYY-MM-DD to DD-MM-YYYY format
        $date = new DateTime($zohoDate);
        return $date->format('d-m-Y');
    } catch (Exception $e) {
        // If date parsing fails, use current date
        $date = new DateTime();
        return $date->format('d-m-Y');
    }
}

function getCustomerTin($data) {
    // Check if TIN is directly in the data (from custom field)
    if (isset($data['customer_tin']) && !empty($data['customer_tin'])) {
        return $data['customer_tin'];
    }
    
    // Check if it's in a common custom field format
    if (isset($data['cf_tax_id']) && !empty($data['cf_tax_id'])) {
        return $data['cf_tax_id'];
    }
    
    // Fallback - not recommended for production
    return '000000000';
}